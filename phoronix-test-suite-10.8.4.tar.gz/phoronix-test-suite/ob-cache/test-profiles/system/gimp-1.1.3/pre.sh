#!/bin/sh

rm -f *.JPG
tar -xjf pts-sample-photos-2.tar.bz2
tar -xf stock-photos-jpeg-2018-1.tar.xz
