#!/bin/sh

rm -f FreeBSD-12.2-RELEASE-amd64-memstick.img.zst
