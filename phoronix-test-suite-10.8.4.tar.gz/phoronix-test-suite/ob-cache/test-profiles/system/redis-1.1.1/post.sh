#!/bin/sh
rm -f dump.rdb
