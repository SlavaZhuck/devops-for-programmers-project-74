#!/bin/sh

rm -f ubuntu-16.04.3-server-i386.img.zst
