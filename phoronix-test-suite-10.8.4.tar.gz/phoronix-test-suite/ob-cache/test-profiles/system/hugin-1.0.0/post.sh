#!/bin/sh

rm -rf pano-pto/
