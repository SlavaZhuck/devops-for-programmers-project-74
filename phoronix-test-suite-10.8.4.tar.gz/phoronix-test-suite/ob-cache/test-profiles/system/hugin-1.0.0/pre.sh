#!/bin/sh

rm -rf pano-pto/
tar -xf pano-pto-1.tar.xz
