#!/bin/sh

rm -f iometer.0.0
